import React, {useState} from 'react';
import Modal from 'react-bootstrap/Modal';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Col, Button, Row, Container, Card, Form} from "react-bootstrap";
import '../../css/CreateUser.css';
import axios from "axios";
import {
    useNavigate
  } from "react-router-dom";
function CreateUser() {

    const [user, setUser] = useState({firstname: "", lastname: "", email: "", password: "",gender: "", birth_date: ""});

    const handleChange = (event) => {
        setUser({...user, [event.target.name]: event.target.value});
    };
    const navigate = useNavigate()
    const handleSubmit = async (event) => {
        
        event.preventDefault();
        try{
            await axios.post("http://localhost:3001/user/create_user",user)
            navigate("/test")

        }catch(err){
            console.log(err)
        }
    };
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    
    return (
        <>
            <Button variant="success" onClick={handleShow}>
                Créer nouveau compte
            </Button>

            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>  S'inscrire <br/> <p className="h6 text-muted">C'est rapide et facile</p></Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <container>
                        <form method="POST" onSubmit={handleSubmit} >
                            <div className="row text-center margin">
                                <div className="col-6">
                                    <label htmlFor="firstname"></label>
                                    <input type="text" name="firstname" placeholder="Prénom" onChange={handleChange}/>
                                </div>
                                <div className="col-6">
                                    <label htmlFor="lastname"></label>
                                    <input type="text" name="lastname" placeholder="Nom de famille"
                                           onChange={handleChange}/>
                                </div>
                            </div>
                            <div className="row text-center margin">
                                <div className="col">
                                    <label htmlFor="email"></label>
                                    <input type="email" name="email" placeholder="Email" className="col-sm-11"
                                           onChange={handleChange}/>
                                    <br/></div>
                            </div>
                            <div className="row text-center margin">
                                <div className="col-6">
                                    <label htmlFor="password"></label>
                                    <input type="password" name="password" placeholder="Nouveau mot de passe"
                                           onChange={handleChange}/>
                                </div>
                                <div className="col-6">
                                    <input type="date" name="birth_date" onChange={handleChange}/>
                                </div>
                            </div>
                            <div>
                                <div className="row text-center margin">
                                    <div className="col-4">
                                        <input type="radio" value="Male" name="gender" onChange={handleChange}/> Homme
                                    </div>
                                    <div className="col-4">
                                        <input type="radio" value="Female" name="gender" onChange={handleChange}/> Femme
                                    </div>
                                    <div className="col-4">
                                        <input type="radio" value="Other" name="gender" onChange={handleChange}/> Autre
                                    </div>
                                </div>
                            </div>
                            <div className="text-center row-cols-4">
                                <input type="submit" value="S'inscrire" className="btn btn-success"/>
                            </div>
                        </form>
                    </container>
                </Modal.Body>
            </Modal>
        </>
    );
}

export default CreateUser;