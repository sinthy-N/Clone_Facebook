import React, { useEffect, useState } from 'react';
import axios from 'axios';
function Test() {
    const [users, setUsers] = useState([]) // Function nécessaire pour récupérer les données à la base de données
    
    
    useEffect(() => {
        const fectAllUsers = async ()=>{
            try{
                const res = axios.get("http://localhost:3001/user/")
                
                setUsers((await res).data)
            }catch(err){
                console.log(err)
            }
        }
        fectAllUsers()
    }, [])
    return (
        <div>
            <h1>Users</h1>
        <div className="users">
            {users.map(user=>(
                <div className="user" key={user.id}>
                    <h2>{user.firstname} {user.lastname}</h2>
                    <h2>{user.email}</h2>
                    <h2>{user.password}</h2>
                    <h2>{user.birth_date}</h2>
                    <h2>{user.gender}</h2>

                </div>
            ))}
        </div>
        </div>
    );
};

export default Test;