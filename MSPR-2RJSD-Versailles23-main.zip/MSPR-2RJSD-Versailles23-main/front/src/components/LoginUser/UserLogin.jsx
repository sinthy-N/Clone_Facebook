import { Col, Button, Row, Container, Card, Form } from "react-bootstrap";
import React, { useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '../../css/login.css';
import CreateUser from "../CreateUser/ModalCreateUser";
export default function () {
    const [user, setUser] = useState({ email: "", password: "" });

    const handleChange = (event) => {
        setUser({ ...user, [event.target.name]: event.target.value });
    };
    const handleSubmit = (event) => {
        event.preventDefault();
    };
    return (
        <form onSubmit={handleSubmit}>
            <div>
                <Container>
                    <Row className="vh-100 d-flex justify-content-end align-items-center">
                        <Col md={8} lg={4} xs={12}>
                            <Card className="shadow">
                                <Card.Body>
                                    <div className="mb-3 mt-md-4">
                                        <div className="mb-3">
                                            <Form>
                                                <Form.Group className="mb-3" controlId="formBasicEmail">
                                                    <Form.Control name="email" type="email" placeholder="Adresse e-mail" />
                                                </Form.Group>
                                                <Form.Group className="mb-3" controlId="formBasicPassword">
                                                    <Form.Control name="password" type="password" placeholder="Mot de passe" />
                                                </Form.Group>
                                                <div className="d-grid mb-3">
                                                    <Button variant="primary" type="submit">Se connecter</Button>
                                                </div>
                                            </Form>
                                            <div className="d-grid">
                                                <a href="" className="text-decoration-none text-center">Mot de passe oublié ?</a>
                                            </div>
                                        </div>
                                        <div className="border border-0.5 Line"></div>
                                    </div>
                                    <div className="d-grid">
                                        <CreateUser />
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                </Container>
            </div>
        </form>
    );
}