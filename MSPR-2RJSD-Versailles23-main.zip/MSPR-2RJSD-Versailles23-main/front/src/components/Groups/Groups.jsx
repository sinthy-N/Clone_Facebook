import { Col, Button, Row, Container, Card, Form } from "react-bootstrap";
import React, { useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '../../css/groups.css';
import CreateGroupButton from "../Groups/CreateGroupButton";
import GroupNewButtons from "../Groups/GroupNewsButtons";
import GroupDiscoverButtons from "../Groups/GroupDiscoverButton";
import GroupYoursButtons from "../Groups/GroupYoursButton";
import SearchBarGroups from "../Groups/searchbar.jsx";
export default function () {
    const [user, setUser] = useState({ email: "", password: "" });

    const handleChange = (event) => {
        setUser({ ...user, [event.target.name]: event.target.value });
    };
    const handleSubmit = (event) => {
        event.preventDefault();
    };
    return (
        <form onSubmit={handleSubmit}>
            <div>
                <Container>
                    <Row className="d-flex justify-content-start align-items-center">
                        <Col md={8} lg={4} xs={12}>
                            <Card className="shadow">
                                <Card.Body>
                                    <div className="mb-3 mt-md-4">
                                        <div className="mb-3">
                                            <h3 class="h3">Groupes</h3>
                                            <div>
                                                <div className="d-grid mb-4" controlId="formBasicSearch">
                                                    <SearchBarGroups />
                                                </div>
                                                
                                                <div className="d-grid" controlId="formBasicEmail">
                                                    <GroupNewButtons/>
                                                </div>

                                                <div className="d-grid" controlId="formBasicPassword">
                                                    <GroupDiscoverButtons/>
                                                </div>

                                                <div className="d-grid mb-2" controlId="formBasicPassword">
                                                    <GroupYoursButtons/>
                                                </div>
                                            </div>

                                            <div className="d-grid">
                                                <CreateGroupButton/>
                                            </div>
                                        </div>
                                        <div className="border border-0.5 Line"></div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                </Container>
            </div>
        </form>
    );
}