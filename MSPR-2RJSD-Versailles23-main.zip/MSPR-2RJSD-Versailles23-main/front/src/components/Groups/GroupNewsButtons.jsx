import button from "bootstrap/js/src/button";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";


function GroupNewButtons() {
    return (
        <button className="btn btn-light" type="submit"><FontAwesomeIcon icon="fa-solid fa-newspaper" />  Votre fil</button>
    )
}
export default GroupNewButtons;