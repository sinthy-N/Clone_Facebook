import button from "bootstrap/js/src/button";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

function GroupDiscoverButtons() {
    return (
        <button className="btn btn-light" type="submit"><FontAwesomeIcon icon="fa-solid fa-compass" />  Découvrir</button>
    )
}
export default GroupDiscoverButtons;