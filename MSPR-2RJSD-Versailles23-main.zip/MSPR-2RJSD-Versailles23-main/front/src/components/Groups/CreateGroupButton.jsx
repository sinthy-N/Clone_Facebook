import button from "bootstrap/js/src/button";


function CreateGroupButton() {
    return (
        <button className="btn btn-primary opacity-75" type="submit"> + Créer un nouveau groupe</button>
    )}


export default CreateGroupButton;