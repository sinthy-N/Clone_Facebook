import button from "bootstrap/js/src/button";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";


function GroupYoursButtons() {
    return (
        <button className="btn btn-light" type="submit"> <FontAwesomeIcon icon="fa-solid fa-people-group" /> Vos groupes</button>
    )
}
export default GroupYoursButtons;