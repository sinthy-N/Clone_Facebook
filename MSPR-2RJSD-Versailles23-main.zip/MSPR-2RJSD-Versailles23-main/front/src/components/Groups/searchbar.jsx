import React, { useState } from 'react';
import '../../css/groups.css';


function SearchBarGroups() {
  const [searchTerm, setSearchTerm] = useState('');

  function handleChange(event) {
    setSearchTerm(event.target.value);
  }

  function handleSubmit(event) {
    event.preventDefault();
    console.log(`Search term: ${searchTerm}`);
  }


  return (
    <form onSubmit={handleSubmit}>
      <input type="text" className="form-control searchbargroups rounded-pill" style={{borderRadius: "40px"}} placeholder="Rechercher des groupes" value={searchTerm} onChange={handleChange} />
    </form>
  );
}

export default SearchBarGroups;
