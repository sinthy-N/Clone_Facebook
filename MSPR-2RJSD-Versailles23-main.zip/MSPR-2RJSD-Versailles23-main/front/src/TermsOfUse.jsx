import React from 'react';
import "./css/TermsOfUse.css";
import hexa from './hexa.png';

const TermsOfUse = () => (
  <div className="terms-of-use">
    <div class="header">
    <img src={hexa} className="logo-hexa" alt="logo" />
    <h1 className='titree'>Termes d'utilisation de Visages</h1>
    </div><br />
    <p>
      Veuillez lire attentivement les termes d'utilisation ci-dessous avant d'utiliser ce site web. En utilisant ce site, vous acceptez d'être lié par ces termes d'utilisation. Si vous n'acceptez pas ces termes, veuillez ne pas utiliser ce site.
    </p>
    <h2>Contenu du site</h2>
    <p>
      Tout le contenu présenté sur ce site, y compris les textes, graphiques, logos, icônes, images, compilations et autres éléments de contenu, est la propriété de ce site ou de ses fournisseurs de contenu et est protégé par les lois internationales sur le droit d'auteur.
    </p>
    <h2>Licence d'utilisation</h2>
    <p>
      Nous accordons une licence limitée, révocable, non-exclusive et non-transférable pour accéder et utiliser ce site et son contenu uniquement à des fins personnelles et non commerciales. Vous ne pouvez pas reproduire, distribuer, afficher, vendre, louer, transmettre ou utiliser de toute autre manière le contenu du site à des fins commerciales sans notre autorisation écrite préalable.
    </p>
    <h2>Modifications des termes d'utilisation</h2>
    <p>
      Nous nous réservons le droit de modifier ces termes d'utilisation à tout moment et sans préavis. Il est de votre responsabilité de consulter régulièrement cette page pour prendre connaissance de tout changement. L'utilisation continue de ce site après toute modification de ces termes constitue votre acceptation de ces modifications.
    </p>
    <h2>Exclusion de garantie</h2>
    <p>
      Ce site et son contenu sont fournis "tels quels" sans garantie d'aucune sorte, expresse ou implicite. Nous ne garantissons pas que l'utilisation de ce site sera ininterrompue ou sans erreur, et nous déclinons toute responsabilité pour les dommages résultant de l'utilisation de ce site, y compris, sans limitation, les dommages directs, indirects, accidentels, punitifs ou consécutifs.
    </p>
    <h2>Limitation de responsabilité</h2>
    <p>
      En aucun cas, nous ne serons tenus responsables des dommages résultant de l'utilisation de ce site, y compris, sans limitation, les dommages directs, indirects, accidentels, punitifs ou consécutifs, même si nous avons été informés de la possibilité de tels dommages. Cette limitation de responsabilité s'applique à toutes les causes d'action, y compris, sans limitation, les contrats, les garanties, les produits défectueux, les négligences ou les délits civils.
</p>
<h2>Liens vers d'autres sites</h2>
<p>
Ce site peut contenir des liens vers d'autres sites qui ne sont pas détenus ou contrôlés par nous. Nous ne sommes pas responsables du contenu ou de la disponibilité de ces sites et n'endossons aucunement les produits, services ou autres matériaux disponibles sur ces sites. L'inclusion de liens vers d'autres sites ne constitue pas une approbation de ces sites ou de leurs produits ou services.
</p>
<h2>Loi applicable</h2>
<p>
Les présentes conditions d'utilisation sont régies et interprétées conformément aux lois de la juridiction applicable et tout litige découlant de l'utilisation de ce site sera soumis à la juridiction exclusive des tribunaux compétents de cette juridiction.
</p>

  </div>
);
export default TermsOfUse;
