import { useEffect, useState } from "react";

const Dashboard = () => {
 const [authenticated, setauthenticated] = useState(null);
 useEffect(() => {
const loggedInUser = localStorage.getItem("authenticated");
if (loggedInUser) {
 setauthenticated(loggedInUser);
}
 }, []);

 if (!authenticated) {
 // Redirect
 } else {
return (
 <div>
<p>Bienvenue sur le site</p>
 </div>
);
 }
};

export default Dashboard;