import React from "react";
import ReactDOM from "react-dom/client";
import reportWebVitals from './reportWebVitals';
import Login from "./components/LoginUser/UserLogin.jsx";
import { createBrowserRouter, RouterProvider, } from "react-router-dom";
import "./css/index.css";
import NavBar from './NavBar';
import FooterConnect from './FooterConnect';
import App from "./App";
import Layout from "./routes/Layout";
import Profile from "./Profile";
import SearchBar from './SearchBar';
import FooterReglages from './FooterReglages';

import TermsOfUse from './TermsOfUse';
import Snake from "./views/snake"

import Tri from './tri';


import Events from "./views/Events/Events";
import Event from "./views/Events/Event";
import NotifCard from "./views/Notifications/NotifCard";

import CreateUser from "./components/CreateUser/ModalCreateUser";
import CreatePost from "./CreatePost";
/* import Chat from "./views/Chat"; */
import InterfacePost from "./InterfacePost";
import ModaleMenu from "./views/ModaleMenu";
import Notifs from "./views/Notifications/Notifs";
import CreateGroupButton from "./components/Groups/CreateGroupButton";
import GroupNewButtons from "./components/Groups/GroupNewsButtons";
import GroupDiscoverButtons from "./components/Groups/GroupDiscoverButton";
import GroupYoursButtons from "./components/Groups/GroupYoursButton";
import LogoutProof from "./views/logout/logout_proof";
import Logout from "./views/logout/logout";
import SearchBarGroups from "./components/Groups/searchbar.jsx";
import Groups from "./components/Groups/Groups.jsx";


let comment = {
  id: "1",
  title: "Mon commentaire",
  content: "contenu du commentaire"
}

let post = {
  id: "1",
  title: "Mon Post",
  content: "contenu du post",
  comments: [comment]
}

let user = {
  name: "valentin",
  profilepics: "https://3.bp.blogspot.com/-IZ5vK7LMilQ/WUDWzb2qKwI/AAAAAAAAA00/OT17K6r3lKoCbmiAGiLR40Daxr-gl93_ACLcBGAs/s1600/20170613_105603.jpg",
  couverturepics: "https://file.diplomeo-static.com/cache/1200x675/00/00/01/93/19387.jpg",
  bio: "je m'appelle Valentin et j'ai 22 ans",
  posts: [post]
}

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />
  },
  {
    path: "/events",
    element: <Events />
  },
  {
    path: "/event",
    element: <Event />
  },
  {
    path: "/notif",
    element: <NotifCard />
  },
  {
    path: "/notifs",
    element: <Notifs />
  },
  {
    path: "/profile",
    element: <Profile user={user} post={post} comment={comment} />
  },
  {
    path: "/login",
    element: <Login />
  },
  {
    path: "/layout",
    element: <Layout />
  },
  {
    path: "/createuser",
    element: <CreateUser />
  },
  {
    path: "/NavBar",
    element: <NavBar />
  },
  {
    path: "/searchbar",
    element: <SearchBar />
  },
  {
    path: "/createpost",
    element: <CreatePost />
  },
    {
    path: "snake",
    element: <Snake/>
  },
  {
    path: "/interfacepost",
    element: <InterfacePost />
  },
  {
    path: "/interfacepost",
    element: <InterfacePost />
  },
  {
    path: "/modalemenu",
    element: <ModaleMenu />
  },
  {
    path: "/footerconnect",
    element: <FooterConnect />
  },
  {

    path: "/footerreglages",
    element: <FooterReglages />
  },
  {
    path: "/tri",
    element: <Tri />
  },

  {
    path: "/terms",
    element: <TermsOfUse />
  },
  {
    path: "/groups",
    element: <Groups />
  },
  {
    path: "/searchbargroups",
    element: <SearchBarGroups />
  },
  {
    path: "/bouton",
    element: <CreateGroupButton />
  },
  {
    path: "groupnews",
    element: <GroupNewButtons />
  },
  {
    path: "groupdiscover",
    element: <GroupDiscoverButtons />
  },
  {
    path: "groupyours",
    element: <GroupYoursButtons />
  },
  {
    path: "logoutproof",
    element: <LogoutProof />
  },
  {
    path: "logout",
    element: <Logout />
  },/* 
  {
    path: "chatfullpage",
    element: <Chat />
  }, */

]);

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
