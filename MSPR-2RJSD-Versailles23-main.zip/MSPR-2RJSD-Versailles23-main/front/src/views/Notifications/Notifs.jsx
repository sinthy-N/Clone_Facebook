import EventCard from "./NotifCard";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../css/Events.css";
import NotifCard from "./NotifCard";

export default function Notifs() {
    return (
        <div class=" bg-white d-flex justify-content-center">
            <br />

            <div class="mt-4">
                <b><h2 class="mt-4" >Vos notifications</h2></b>

                <div> <NotifCard picture="https://st2.depositphotos.com/1872669/6765/i/600/depositphotos_67652273-stock-photo-portrait-of-beautiful-girl-outdoors.jpg" name=" Lucinda Vielmaison" motif="a envoyé une invitation d'amitié" date=" 02 Décembre 2023" /></div>
                <div> <NotifCard id="hover" picture="https://media1.popsugar-assets.com/files/thumbor/1nlhpkSeeH4FTwXMFjKUVxrJp5A/fit-in/2048xorig/filters:format_auto-!!-:strip_icc-!!-/2015/06/23/903/n/2589278/85d3701aa8f2b16f_GettyImages-170381061_master/i/Hot-Pictures-Henry-Cavill.jpg" name="Henry Cavill" motif="invite à un évènement" date="10 Août 2023" /></div>
                <div> <NotifCard id="hover" picture="https://pbs.twimg.com/profile_images/1358156723547217922/zbwm0DkN_400x400.jpg" name="Marie Pierre" motif="a envoyé un message" date="09 Janvier 2022" /></div>
            </div>


        </div>
    )
}