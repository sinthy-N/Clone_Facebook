import "bootstrap/dist/css/bootstrap.min.css";
import "../../css/Events.css";
import { faShare } from "@fortawesome/free-solid-svg-icons"
import { faEllipsis } from "@fortawesome/free-solid-svg-icons"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faStar } from "@fortawesome/free-solid-svg-icons"

function NotifCard(props) {

    return (
        <div class="mb-3 rounded" id="effect">
            <div class="m-3">
                <div class="d-flex flex-row">
                    <a href="#"><img className="circleUser" src={props.picture} alt="" srcset="" /></a>
                    <div class="ms-5 mt-5">
                        <p> <b>{props.name}</b> vous {props.motif};</p>
                        <p>Le {props.date}</p>

                    </div>

                </div>

            </div>
        </div>
    )

}
export default NotifCard;