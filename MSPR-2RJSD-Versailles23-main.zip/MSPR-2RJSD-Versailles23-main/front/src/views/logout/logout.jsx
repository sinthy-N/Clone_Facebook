import React, { useState } from "react";
const Logout = () => {
    const [state, setState] = useState({
    username: "currentUsername",
    email: "currentEmail",
  });

  const clearState = () => {
    setState({
        username: null,
        email: null,
    });
    window.location = '/login';
  };

  return (
    <div>
      <button onClick={clearState}>Logout</button>
    </div>
  );
};

export default Logout;
