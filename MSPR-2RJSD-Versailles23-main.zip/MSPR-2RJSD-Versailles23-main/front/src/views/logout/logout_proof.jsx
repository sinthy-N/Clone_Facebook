import React, { useState } from "react";
const LogoutProof = () => {
    const [state, setState] = useState({
    username: "currentUsername",
    email: "currentEmail",
  });

  const clearState = () => {
    setState({
        username: null,
        email: null,
    });
  };

  return (
    <div>
      <div>{JSON.stringify(state)}</div>
      <button onClick={clearState}>Logout</button>
    </div>
  );
};

export default LogoutProof;
