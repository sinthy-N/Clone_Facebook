import React, { useState, useEffect } from 'react';
import logo_event from '../img/evenements.png';
import logo_amis from '../img/amis.png';
import logo_favoris from '../img/favoris.png';
import logo_actualite from '../img/fil_actualite.png';
import logo_groupes from '../img/groupes.png';
import logo_pages from '../img/pages.png';
import logo_recent from '../img/recent.png';
import logo_pubs from '../img/pubs.png';
import logo_jouer from '../img/jouer.png';
import logo_watch from '../img/watch.png';
import logo_pay from '../img/facebook_pay.png';
import logo_market from '../img/marketPlace.png';
import logo_gestionnaire from '../img/gestionnaire.png';
import logo_business from '../img/buisness.png';
import logo_climatologie from '../img/climatologie.png';
import logo_covid from '../img/covid.png';
import logo_service from '../img/crise.png';
import logo_sante from '../img/sante.png';
import logo_collectes from '../img/collectes.png';
import logo_actualites from '../img/Actu.png';
import logo_nothing from '../img/nothing.svg';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faBookOpen, faStar, faFlag, faBullhorn, faUserGroup, faCalendar, faShoppingBasket, faCoins } from '@fortawesome/free-solid-svg-icons';
import '../css/ModaleMenu.css'; // Import a CSS file with styles for the menu
import { useRef } from 'react';

function ModaleMenu() {
    const [isOpen, setIsOpen] = useState(false);
    const [search, setSearch] = useState('');

    const handleOpen = () => {
        setIsOpen(true);
    };

    const handleClose = () => {
        setIsOpen(false);
    };

    let menuRef = useRef(); // Create a ref to the menu element
    let buttonRef = useRef(); // Create a ref to the menu element


    const menuItems = [{
        title: 'Social',
        items: [
            {
                name: 'Evenements',
                logo: logo_event
            },
            {
                name: 'Amis',
                logo: logo_amis
            },
            {
                name: 'Groupes',
                logo: logo_groupes
            },
            {
                name: 'Fil actualité',
                logo: logo_actualite
            },
            {
                name: 'Favoris',
                logo: logo_favoris
            },
            {
                name: 'Plus récentes',
                logo: logo_recent
            },
            {
                name: 'Pages',
                logo: logo_pages
            }
        ]
    },
    {
        title: 'Divertissement',
        items: [
            {
                name: 'Vidéo de Gaming',
                logo: logo_jouer
            },
            {
                name: 'Jouer à des jeux',
                logo: logo_jouer
            },
            {
                name: 'Watch',
                logo: logo_watch
            },
            {
                name: 'Vidéo en direct',
                logo: logo_event
            }
        ]
    },
    {
        title: 'Shopping',
        items: [
            {
                name: 'Facebook Pay',
                logo: logo_pay
            },
            {
                name: 'Market Place',
                logo: logo_market
            }
        ]
    },
    {
        title: 'Professionel',
        items: [
            {
                name: 'Gestionnaire de publicités',
                logo: logo_gestionnaire
            },
            {
                name: 'Business Manager',
                logo: logo_business
            },
            {
                name: 'Espace Pubs',
                logo: logo_pubs
            }
        ]
    },
    {
        title: 'Ressources communautaires',
        items: [
            {
                name: 'Climatologie',
                logo: logo_climatologie
            },
            {
                name: 'COVID-19',
                logo: logo_covid
            },
            {
                name: 'Crise',
                logo: logo_service
            },
            {
                name: 'Santé',
                logo: logo_sante
            },
            {
                name: 'Collectes',
                logo: logo_collectes
            },
            {
                name: 'Actualités',
                logo: logo_actualites
            }
        ]
    },

    ];

    const filteredMenuItems = menuItems.map((menuItem) => {
        return {
            ...menuItem, // The "..." in the code is the spread operator, which allows an object to expand its properties and values.
            items: menuItem.items.filter((item) => item.name.toLowerCase().includes(search.toLowerCase()))
        }
    });


    useEffect(() => {
        let handler = (event) => {
            if (!menuRef.current.contains(event.target) && !buttonRef.current.contains(event.target)) { // If the click was outside the menu, close it
                setIsOpen(false);
            }
        }

        document.addEventListener("mousedown", handler); // Add an event listener for clicks

        return () => {
            document.removeEventListener("mousedown", handler); // Remove the event listener when the component unmounts
        }
    });

    return (
        <>
            <button ref={buttonRef} onClick={isOpen ? handleClose : handleOpen}>Menu</button>
            {isOpen && (
                <div ref={menuRef} className="modale-menu">
                    <h4>Menu</h4>
                    <div className='modale-display'>
                        <div>
                            <input className="form-control" type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Rechercher" style={{ width: "90%", marginLeft: "10px" }} />
                            {filteredMenuItems.filter(menuItem => menuItem.items.length > 0).length > 0 ? (
                                filteredMenuItems.filter(menuItem => menuItem.items.length > 0).map((menuItem, index) => (
                                    <div key={index} style={{ width: "90%" }} className='modale-conteneur_1'>
                                        <div className='modale-title'>{menuItem.title}</div>
                                        <ul>
                                            {menuItem.items.map((item, index) => (
                                                <li key={index} className={'d-flex align-items-center'}>
                                                    <img src={item.logo} alt={item.name} className={'modale-logo'}/>
                                                    {item.name}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                ))
                            ) : (
                                <div className='modale-conteneur_1'>
                                    <img src={logo_nothing} alt="logo_nothing" />
                                    <h6>Nous n'avons rien trouvé</h6>
                                </div>
                            )}
                        </div>
                        <div style={{ width: "40%", marginTop: "3em" }} className='modale-conteneur_2'>
                            <div>
                                <ul>
                                    <div className='modale-title'>Créer</div>
                                    <li className='modale-icon'>
                                        <FontAwesomeIcon icon={faPenToSquare} className='modale-icon fa-lg' />
                                        Publication</li>
                                    <li className='modale-icon'>
                                        <FontAwesomeIcon icon={faBookOpen} className='modale-icon fa-lg' />
                                        Story</li>
                                    <li className='modale-icon'>
                                        <FontAwesomeIcon icon={faStar} className='modale-icon fa-lg' />
                                        Favoris</li>
                                    <hr />
                                    <li className='modale-icon'>
                                        <FontAwesomeIcon icon={faFlag} className='modale-icon fa-lg' />
                                        Page</li>
                                    <li className='modale-icon'>
                                        <FontAwesomeIcon icon={faBullhorn} className='modale-icon fa-lg' />
                                        Publicité</li>
                                    <llii className='modale-icon'>
                                        <FontAwesomeIcon icon={faUserGroup} className='modale-icon fa-lg' />
                                        Groupe</llii>
                                    <li className='modale-icon'>
                                        <FontAwesomeIcon icon={faCalendar} className='modale-icon fa-lg' />
                                        Evenement</li>
                                    <li className='modale-icon'>
                                        <FontAwesomeIcon icon={faShoppingBasket} className='modale-icon fa-lg' />
                                        MarketPlace</li>
                                    <li className='modale-icon'>
                                        <FontAwesomeIcon icon={faCoins} className='modale-icon fa-lg' />
                                        Dons</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            )}
        </>
    );
};

export default ModaleMenu;