import "bootstrap/dist/css/bootstrap.min.css";
import "../../css/Events.css";
import { faShare } from "@fortawesome/free-solid-svg-icons"
import { faEllipsis } from "@fortawesome/free-solid-svg-icons"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faStar } from "@fortawesome/free-solid-svg-icons"

function EventCard(props) {

    return (
        <div >
            <div class="card me-5" >

                <a href="#"><img class="card-img-top" src={props.image} alt="" srcset="" /></a>
                <div class="d-flex flex-row-reverse card-img-overlay">< FontAwesomeIcon icon={faEllipsis} /></div>

                <div class="card-body">
                    <h5 class="card-title text-danger">{props.datev}</h5>
                    <h5 class="card-title">{props.title}</h5>
                    <p class="text-left card-text">{props.content}</p>
                    <p class="text-left card-text text-weight-light"> {props.place} </p>
                    <p class="text-left card-text">Publié le: {props.date} par {props.author} </p>
                    <a href="#" class="btn  btn-primary me-4" > <FontAwesomeIcon icon={faStar} /> Intéressé</a>
                    <a href="#" class="btn btn-warning " > <FontAwesomeIcon icon={faShare} /> Partager</a>
                </div>
            </div>



        </div>


    )

}
export default EventCard;