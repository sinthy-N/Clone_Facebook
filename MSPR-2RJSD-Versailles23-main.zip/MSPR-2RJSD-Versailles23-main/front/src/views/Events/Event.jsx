import "bootstrap/dist/css/bootstrap.min.css";
import "../../css/Events.css";
import { faEarth, faEllipsis, faLocationDot, faPhone, faShare, faUser, faUsers } from "@fortawesome/free-solid-svg-icons"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faStar } from "@fortawesome/free-solid-svg-icons"
import { faCircleCheck } from "@fortawesome/free-solid-svg-icons"
import { faEnvelope } from "@fortawesome/free-solid-svg-icons"



export default function Event(props) {
    return (
        <div class="jumbotron  text-dark rounded bg-secondary m-2">
            <div class=" bg-white px-0 p-3 p-md-5">
                <div class="img-fluid d-flex justify-content-center "><img className="imgsize" src="https://images.ctfassets.net/hrltx12pl8hq/a2hkMAaruSQ8haQZ4rBL9/8ff4a6f289b9ca3f4e6474f29793a74a/nature-image-for-website.jpg?fit=fill&w=480&h=320" alt="" /></div><br />
                <b> <h2 class="text-danger">Date de l'évènement</h2></b>
                <b><h1 class="display-3">Le Titre de l'évènement</h1></b>
                <h3 class="text-secondary">Le lieu de l'évènement</h3>
                <hr />
                <div class="d-flex flex-row justify-content-between" >
                    <button class=" d-flex btn  btn-sm" type="button"> <b><span class="display-9"> A propos</span></b></button>
                    <div class=" d-flex btn-group ms-4">
                        <button class=" btn btn-secondary btn-sm" type="button"> <FontAwesomeIcon icon={faStar} />  Ca m'intéresse</button>
                        <button class=" ms-2 btn btn-secondary btn-sm" type="button"> <FontAwesomeIcon icon={faCircleCheck} /> Je participe</button>
                        <button class=" ms-2 btn btn-secondary btn-sm" type="button"><FontAwesomeIcon icon={faEnvelope} />  Inviter</button>
                        <button class=" ms-2 btn btn-secondary btn-sm" type="button"><FontAwesomeIcon icon={faShare} /></button>
                        <button class=" ms-2 btn btn-secondary btn-sm" type="button"><FontAwesomeIcon icon={faEllipsis} /></button>
                    </div>
                </div>
                <p class="lead my-3"></p>
                <p class="lead mb-0"><a href="#" class="text-white font-weight-bold">Continue reading...</a></p>
            </div><br />
            <div class=" bg-yellow p-4">
                <div class="row">
                    <div class="col-md-6">
                        <div class="bg-white mb-3 rounded">

                            <div class=" m-3">
                                <h2>Détails</h2>
                                <div class="d-flex flex-row"><FontAwesomeIcon icon={faUsers} /> <p class="ms-4"> 5k personnes ont répondu</p></div>
                                <div class="d-flex flex-row"><FontAwesomeIcon icon={faUser} /> <p class="ms-4"> Motif de l'évènement </p></div>
                                <div class="d-flex flex-row"><FontAwesomeIcon icon={faLocationDot} /> <p class="ms-4"> Lieu de l'évènement </p></div>
                                <div class="d-flex flex-row"><FontAwesomeIcon icon={faEarth} /><p class="ms-4"> Tout le monde sur ou en dehors  de facebook</p> </div>
                                <p> Petite description de l'évènement</p>
                            </div>
                        </div>
                        <div class=" bg-white rounded pb-2">
                            <b><h2>Rencontrez vos organisateurs</h2></b>
                            <div>
                                <img src="https://www.access-market.com/modules/ph_simpleblog/featured/339.jpg" class="card-img-top mb-3" alt="" />
                            </div>

                            <div class="d-flex justify-content-center">
                                <button class=" ms-2 btn btn-secondary btn-lg" type="button"><FontAwesomeIcon icon={faPhone} /> Appeler maintenant</button></div>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="row bg-white mb-3 rounded">
                            <div >
                                <img src="https://media.istockphoto.com/id/925433040/vector/city-navigation-driving-map.jpg?s=170667a&w=0&k=20&c=_C91uZrpQhbSsaICwnOntmUHwqCoflvUjoaMmPbl9XU=" class="card-img-top" alt="..." />
                                <div class="card-body ">
                                    <p class="card-text">Paris expo porte de Versailles</p>
                                    <p class="card-text">Adresse du lieu de l'évènement </p>
                                </div>
                            </div>

                        </div>
                        <div class="row bg-white rounded pb-3">
                            <div class="d-flex justify-content-between">
                                <b><h5>Invités</h5></b>
                                <a href=""><h5>Voir tout </h5></a>
                            </div>
                            <div class="d-flex justify-content-around">
                                <button class=" ms-2 btn  btn-sm" type="button"><h5><b> 528 </b>participent</h5></button>
                                <button class=" ms-2 btn  btn-sm" type="button"><h5><b> 5k </b>sont intéressés</h5></button>
                            </div>
                            <hr />
                            <b><h5>Participez avec des amis </h5></b>
                            <p>ami 1 </p>
                            <p>ami 2 </p>
                            <p>ami 3 </p>
                        </div>

                    </div>
                </div>



            </div>
        </div>

    )
}

