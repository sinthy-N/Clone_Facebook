import EventCard from "./EventCard";

export default function Events() {
    return (
        <div className='container'>
            <header class=' h1 ms-5 me-5'>
                Découvrez des évènements
            </header>
            <br />
            <div class=" ms-5 btn-group">
                <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Ma position
                </button>
                <ul class="dropdown-menu">
                    ...
                </ul>
            </div>
            <div class="btn-group ms-4">
                <button class="btn btn-secondary btn-sm" type="button">
                    N'importe quelle date
                </button>
                <button type="button" class="btn btn-sm btn-secondary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false">
                    <span class="visually-hidden">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu">
                    ...
                </ul>
            </div>
            <div class="btn-group ms-4">
                <button class="btn btn-secondary btn-sm" type="button">
                    Meilleurs
                </button>
            </div>
            <div class="btn-group ms-4">
                <button class="btn btn-secondary btn-sm" type="button">
                    Amie(s)
                </button>
            </div>
            <div class="btn-group ms-4">
                <button class="btn btn-secondary btn-sm" type="button">
                    Suivis
                </button>
            </div>
            <div class="btn-group ms-4">
                <button class="btn btn-secondary btn-sm" type="button">
                    En cours
                </button>
            </div>
            <div class='mt-5 ms-5'>
                <div class='d-flex flex-row'>
                    <EventCard image='https://st.depositphotos.com/2309453/2637/i/450/depositphotos_26376385-stock-photo-smiling-man-indoors.jpg' datev="17/12/2023 à 15/05/2023" title=' Célébration du 50 anniversaire de Sébastien Dhérines' content='Soyez au rendez-vous' author='Brest' place="Château de Versailles" date='25-02-22' />  <br />
                    <EventCard image='https://st.depositphotos.com/2309453/2637/i/450/depositphotos_26376385-stock-photo-smiling-man-indoors.jpg' datev="17/12/2023 à 15/05/2023" title=' Célébration du 50 anniversaire de Sébastien Dhérines' content='Soyez au rendez-vous' author='Brest' place="Château de Versailles" date='25-02-22' /> <br />
                    <EventCard image='https://st.depositphotos.com/2309453/2637/i/450/depositphotos_26376385-stock-photo-smiling-man-indoors.jpg' datev="17/12/2023 à 15/05/2023" title=' Célébration du 50 anniversaire de Sébastien Dhérines' content='Soyez au rendez-vous' author='Brest' place="Château de Versailles" date='25-02-22' /> <br />
                </div>
            </div>
        </div>
    )
}