import React from "react";
import "../css/chat.css";
// import Nav from "./components/nav/Nav";
import ChatBody from "./chatcompontents/chatbody/chatbody";

function App() {
  return (
    <div className="__main">
      <ChatBody />
    </div>
  );
}

export default App;