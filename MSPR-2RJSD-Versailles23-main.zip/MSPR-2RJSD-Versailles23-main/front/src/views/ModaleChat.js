import React, { useState, useEffect } from 'react';

import ChatBody from "./modaleChat/body/chatbody";

import { useRef } from 'react';

function ModaleChat() {
    const [isOpen, setIsOpen] = useState(false);

    const handleOpen = () => {
        setIsOpen(true);
    };
    const handleClose = () => {
        setIsOpen(false);
    };

    let buttonRef = useRef(); // Create a ref to the menu element

    return (
        <>
            {!isOpen && (<button ref={buttonRef} onClick={handleOpen}>Open Chat</button>)}
            {isOpen && (<div><button ref={buttonRef} onClick={handleClose}>X</button> <div><ChatBody /></div></div>)}
        </>
    );
};

export default ModaleChat;