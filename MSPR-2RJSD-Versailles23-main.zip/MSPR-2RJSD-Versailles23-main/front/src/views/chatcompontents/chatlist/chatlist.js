import React, { Component } from "react";
import "./chatlist.css";
import ChatListItems from "./chatlistitems";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPlus, faPaperPlane, faEllipsis, faSearch } from '@fortawesome/free-solid-svg-icons'

export default class ChatList extends Component {
  allChatUsers = [
    
  ];
  constructor(props) {
    super(props);
    this.state = {
      allChats: this.allChatUsers,
    };
  }
  render() {
    return (
      <div className="main__chatlist">
        <button className="btn shadow d-flex">
          <i className="fa fa-plus"><FontAwesomeIcon className='icon justify-content-center iconn' icon={faPlus} /></i>
          <span>New conversation</span>
        </button>
        <div className="chatlist__heading">
          <h2>Chats</h2>
          <button className="btn-nobg">
            <i className="fa fa-ellipsis-h"><FontAwesomeIcon className='icon justify-content-center iconn' icon={faEllipsis} /></i>
          </button>
        </div>
        <div className="chatList__search">
          <div className="search_wrap">
            <input type="text" placeholder="Search Here" required />
            <button className="search-btn">
              <i className="fa fa-search"><FontAwesomeIcon className='icon justify-content-center iconn' icon={faSearch} /></i>
            </button>
          </div>
        </div>
        <div className="chatlist__items">
          {this.state.allChats.map((item, index) => {
            return (
              <ChatListItems
                name={item.name}
                key={item.id}
                animationDelay={index + 1}
                active={item.active ? "active" : ""}
                isOnline={item.isOnline ? "active" : ""}
                image={item.image}
              />
            );
          })}
        </div>
      </div>
    );
  }
}