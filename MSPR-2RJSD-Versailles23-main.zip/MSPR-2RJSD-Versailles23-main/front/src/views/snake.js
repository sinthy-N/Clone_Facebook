import Board from './Board/Board.jsx';

import './App.css';

const App = () => (
  <div className="App">
    <Board></Board>
  </div>
);

export default App;
