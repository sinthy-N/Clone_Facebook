import React from 'react';
import Button from 'react-bootstrap/esm/Button';

const FooterConnect = () => (
    <footer className="footer">
        <Button className='btnfooter' variant="primary" type="submit">Se connecter</Button>
        <Button className='btnfooter' variant="success" type="submit">Créer nouveau compte</Button>
        <br />
    </footer>


);

export default FooterConnect;