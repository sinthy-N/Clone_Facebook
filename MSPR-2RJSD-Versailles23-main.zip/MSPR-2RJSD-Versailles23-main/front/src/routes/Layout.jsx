import { useState } from "react";
import "../css/Layout.css";
import NavBar from "../NavBar";

function Layout({ children }) {
  return (
    <div class="layout">
      
      <div class="middle-section">
        <LeftDisplay />
        <div class="center-column">
          {children}
        </div>
        <RightDisplay />
      </div>
    </div>
  );
}

function LeftDisplay() {
  /* const [displayLeft, setDisplayLeft] = useState(true);
  return (
    <div>
      <button onClick={() => setDisplayLeft((prevState) => !prevState)}>
        Toggle
      </button>
      {displayLeft ? <div class="side-columns">Call the component</div> : ""}
    </div>
  ); */
}

function RightDisplay() {
  /* const [displayRight, setDisplayRight] = useState(true);
  return (
    <div>
      <button onClick={() => setDisplayRight((prevState) => !prevState)}>
        Toggle
      </button>
      {displayRight ? <div class="side-columns">Call the component</div> : ""}
    </div>
  ); */
}

export default Layout;
