import React from 'react';


const FooterReglages = () => (
    <footer className="footer">
        <a href="#">About</a>&nbsp;
        <a href="#">Create ad</a>&nbsp;
        <a href="#">Create Page</a>&nbsp;
        <a href="#">Terms</a><br />
        <a href="#">Developers</a>&nbsp;
        <a href="#">Careers</a>&nbsp;
        <a href="#">Privacy Policy</a>&nbsp;
        <a href="#">Cookies</a>
    </footer>

);

export default FooterReglages;