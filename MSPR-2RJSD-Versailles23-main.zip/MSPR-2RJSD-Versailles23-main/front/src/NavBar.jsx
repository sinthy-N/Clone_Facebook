
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import './css/index.css';
import hexa from './hexa.png';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faHouse, faUserGroup, faCircleUser, faClapperboard, faShop, faHeadset, faBars, faBell, faMessage } from '@fortawesome/free-solid-svg-icons'




function NavBar() {
  return (
    <Navbar className='navbar' bg="light" expand="lg" collapseOnSelect>
      <Container fluid>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Form className="d-flex">
          <Navbar.Brand href="#"><img src={hexa} className="logo-hexa col-sm" alt="logo" /></Navbar.Brand>

          <Nav>
            <Nav.Link href="#action2"><FontAwesomeIcon className='icon justify-content-center iconn' icon={faHouse} /></Nav.Link>
            <Nav.Link href="#action2"><FontAwesomeIcon className='icon justify-content-center iconn' icon={faUserGroup} /></Nav.Link>
            <Nav.Link href="#action2"><FontAwesomeIcon className='icon justify-content-center iconn' icon={faClapperboard} /></Nav.Link>
            <Nav.Link href="#action3"><FontAwesomeIcon className='icon justify-content-center iconn' icon={faShop} /></Nav.Link>
            <Nav.Link href="#action3"><FontAwesomeIcon className='icon justify-content-center iconn' icon={faHeadset} /></Nav.Link>
            <Nav.Link href="#" disabled>
            </Nav.Link>
          </Nav>
        </Form>
        <Form className="d-flex">
          <Nav.Link href="#action3"><FontAwesomeIcon className='icon justify-content-center iconn' icon={faBars} /></Nav.Link>
          <Nav.Link href="#action3"><FontAwesomeIcon className='icon justify-content-center iconn' icon={faMessage} /></Nav.Link>
          <Nav.Link href="#action3"><FontAwesomeIcon className='icon justify-content-center iconn' icon={faBell} /></Nav.Link>
          <Nav.Link href="#action3"><FontAwesomeIcon className='icon justify-content-center iconn' icon={faCircleUser} /></Nav.Link>
        </Form>
      </Container>
    </Navbar>

  );
}

export default NavBar;