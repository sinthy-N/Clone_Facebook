import './css/App.css';

import "bootstrap/dist/css/bootstrap.min.css";


import SearchBar from './SearchBar';


function App() {
  return (
    <div className="App">

    </div>
  );
}
export default App;
