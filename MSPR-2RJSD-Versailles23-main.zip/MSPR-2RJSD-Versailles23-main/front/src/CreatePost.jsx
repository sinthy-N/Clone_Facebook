import 'bootstrap/dist/css/bootstrap.css';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFlag, faLocationDot, faFaceLaugh, faUserTag, faImages, faEarthAmericas, faUserGroup, faUser, faLock, faGear, faArrowLeftLong, faEllipsis, faCaretDown } from '@fortawesome/free-solid-svg-icons'
import axios from "axios";


import humeur from './icones/humeur.png';
import gallery from './icones/gallery.png';
import video from './icones/video.png';
import flag from './icones/flag.png';
import gif from './icones/gif.png';



import React, { useState } from 'react';
import './css/CreatePost.css';
import 'bootstrap/dist/css/bootstrap.css';
import { Button, Modal, Form, ListGroup, ButtonGroup, } from 'react-bootstrap';


//les import des posts
import { Dropdown, DropdownButton, Image, Container, Row, Col, Badge, Accordion, Card, Media, Collapse, setImage } from 'react-bootstrap';
import { faThumbsUp, faCircleHeart, faGrinSquint, faCommentAlt } from "@fortawesome/free-solid-svg-icons";

import { useNavigate } from "react-router-dom";

function CreatePost() {


  //back 
  const [post, setPost] = useState({ content: "", image: "" });

  const handleChange = (event) => {
    setPost({ ...post, [event.target.name]: event.target.value });
  };
  const navigate = useNavigate()
  const handleSubmit = async (event) => {

    event.preventDefault();
    try {
      await axios.post("http://localhost:3001/post/create_post", post)
      navigate("/test")

    } catch (err) {
      console.log(err)
    }
  };




  //front
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);


  //Modal suivante
  const [modalState, setModalState] = useState(1);

  //List Amis
  const [selectedOption, setSelectedOption] = useState('');
  const handleOptionChange = (event) => {
    setSelectedOption(event.target.value);
  };

  //Afficher les posts
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const toggle = () => setDropdownOpen(prevState => !prevState);
  const [open, setOpen] = useState(false);

  //inserer une image
  const [showDiv, setShowDiv] = useState(false);
  const [image, setImage] = useState(null);

  const handleClick = () => {
    setShowDiv(!showDiv);
  };

  const handleFileUpload = (event) => {
    setImage(event.target.files[0]);
  };

  const handleDrop = (event) => {
    event.preventDefault();
    setImage(event.dataTransfer.files[0]);
  };



  return (
    <>

      <div className="container-fluid">
        <div className="row justify-content-evenly">
          <div className="col-11 col-lg-12 pb-5">
            <div className="d-flex flex-column justify-content-center w-100 mx-auto" style={{ paddingTop: '56px', maxWidth: '680px' }}>
              <div className="bg-white p-3 mt-3 rounded border shadow">
                <div className="d-flex">

                  <div className="p-1">
                    <img src="https://profileme.app/wp-content/uploads/2021/01/cropped-ProfileMe-06.jpg" alt="avatar" className="rounded-circle me-2" style={{ width: '38px', height: '38px', objectFit: 'cover' }} />
                  </div>
                  <Button variant="secondary" className="form-control rounded-pill border-0 pointer" style={{ width: '100%', backgroundColor: 'lightgray' }} onClick={handleShow}>
                    Quoi de neuf, Hexagone ?
                  </Button>
                </div>


                <hr />

                <div className="options d-flex flex-column flex-lg-row mt-3">
                  <div className="list dropdown-item rounded d-flex align-items-center justify-content-center" type="button">
                    <img src={video} alt="Humeur icon" />
                    <p className="m-0 text-muted">Vidéo en direct</p>
                  </div>

                  <div className="list dropdown-item rounded d-flex align-items-center justify-content-center" type="button">
                    <img src={gallery} alt="Humeur icon" />
                    <p className="m-0 text-muted">Photo / Vidéo</p>
                  </div>

                  <div className="list dropdown-item rounded d-flex align-items-center justify-content-center" type="button">
                    <img src={humeur} alt="Humeur icon" />
                    <p className="m-0 text-muted">Humeur / Activité</p>
                  </div>
                </div>
              </div>


            </div>
          </div>




          <div className="col-12 col-lg-3">
          </div>
        </div>
      </div>
      {modalState === 1 && (
        <Modal show={show} onHide={handleClose} centered>
          <Modal.Header closeButton>
            <Modal.Title>Create Post</Modal.Title>
          </Modal.Header>
          <Modal.Body className="modal-body">
            <div className="my-1 p-1">
              <div className="d-flex flex-column">
                <div className="d-flex align-items-center">
                  <div className="p-2">
                    <img src="https://profileme.app/wp-content/uploads/2021/01/cropped-ProfileMe-06.jpg" alt="from fb" className="rounded-circle" style={{ width: '38px', height: '38px', objectFit: 'cover' }} />
                  </div>
                  <div>
                    <p className="m-0 fw-bold">John</p>
                    <Button variant="light" style={{ padding: '2px 5px', fontSize: '12px', backgroundColor: 'lightgray' }} onClick={() => setModalState(2)}>
                      <FontAwesomeIcon className="fs-5" icon={faUserGroup} />
                      <span>Friends</span>
                      <FontAwesomeIcon className="fs-5" icon={faCaretDown} />
                    </Button>

                  </div>

                </div>

                <form method="POST" onSubmit={handleSubmit} >
                  <div>
                    <textarea htmlFor="content" cols={30} rows={5} className="form-control border-0" placeholder="Quoi de neuf hexagone ?" defaultValue={""} onChange={handleChange} />
                  </div>
                  {showDiv && (
                    <div
                      onDrop={handleDrop}
                      onDragOver={(event) => event.preventDefault()}
                      style={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", height: "100%", width: "100%" }}
                    >
                      {!image && (
                        <Button
                          variant="primary"
                          style={{ height: "100%", width: "100%" }}
                          onClick={() => document.getElementById("file-input").click()}
                        >
                          Choose File
                        </Button>
                      )}
                      {image && (
                        <>
                          <div style={{ display: "flex", justifyContent: "space-between" }}>
                            <Button variant="primary" style={{ marginRight: "1rem" }}>
                              Modify
                            </Button>
                            <Button variant="primary">Ajouter des photos/vidéos</Button>
                            <Button variant="danger" onClick={() => setImage(null)}>Close</Button>
                          </div>
                          <img htmlFor="image" src={URL.createObjectURL(image)} alt="" style={{ marginTop: "1rem" }} onChange={handleChange} />
                        </>
                      )}

                      <div>
                        <input
                          type="file"
                          id="file-input"
                          style={{ display: "none" }}
                          onChange={handleFileUpload}
                        />
                      </div>
                    </div>
                  )}
                </form>


                <div className="d-flex justify-content-between align-items-center">
                  <img src="https://www.facebook.com/images/composer/SATP_Aa_square-2x.png" className="pointer" alt="fb text" style={{ width: '30px', height: '30px', objectFit: 'cover' }} />
                  <i className="fa-regular fa-face-smile-relaxed" />
                </div>
                <div className="d-flex justify-content-between border border-1 border-secondary rounded p-3 mt-3">
                  <p onClick={() => setModalState(3)} className="m-0 text-black" style={{ textDecoration: "none" }}>Ajouter a votre publication</p>
                  <div>
                    <FontAwesomeIcon className="fs-5 text-success pointer mx-1" icon={faImages} onClick={() => setShowDiv(!showDiv)} />
                    <FontAwesomeIcon className="fs-5 text-primary pointer mx-1" icon={faUserTag} onClick={() => setModalState(5)} />
                    <FontAwesomeIcon className="fs-5 text-warning pointer mx-1" icon={faFaceLaugh} />
                    <FontAwesomeIcon className="fs-5 text-danger pointer mx-1" icon={faLocationDot} />
                    <FontAwesomeIcon className="fs-5 text-info pointer mx-1" icon={faFlag} />
                    <FontAwesomeIcon className="fs-5 text-secondary pointer mx-1" icon={faEllipsis} onClick={() => setModalState(3)} />
                  </div>
                </div>


              </div>
            </div>

          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="secondary" onClick={handleClose}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>
      )}

      {modalState === 2 && (
        <Modal show={show} onHide={handleClose} centered>
          <Modal.Header closeButton>

            <Button variant="light" className="rounded-circle d-flex align-items-center justify-content-center p-3 mr-3" style={{ height: '50px', width: '50px' }} onClick={() => setModalState(1)}>
              <FontAwesomeIcon className="fs-5" icon={faArrowLeftLong} />
            </Button>
            <Modal.Title>Audience de la publication</Modal.Title>
          </Modal.Header>
          <Modal.Body className="modal-body">
            <div class="content">
              <p>Qui peut voir votre publication ?</p>
              <span>Votre publication apparaîtra dans le Fil, sur votre profil et dans les résultats de recherche.</span><br />
              <span>Votre audience par défaut est définie sur Amis, mais vous pouvez modifier l’audience de cette publication en particulier.</span>
            </div>
            <div style={{ height: '500px', overflow: 'auto' }}>
              <Form>
                <ListGroup>
                  <ListGroup.Item action variant="light" className="d-flex justify-content-between align-items-center h-100">
                    <Button variant="light" className="rounded-circle d-flex align-items-center justify-content-center p-3 mr-3" style={{ height: '50px', width: '50px' }}>
                      <FontAwesomeIcon className="fs-5" icon={faEarthAmericas} />
                    </Button>
                    <div>
                      <span class="text-sm">Public <br /> Tous le monde sur ou en dehors de Facebook</span>
                    </div>
                    <Form.Check
                      type="radio"
                      label={
                        <></>
                      }
                      name="radio-group"
                      value="public"
                      checked={selectedOption === "public"}
                      onChange={handleOptionChange}
                    />
                  </ListGroup.Item>
                  <ListGroup.Item action variant="light" className="d-flex justify-content-between align-items-center h-100">
                    <Button variant="light" className="rounded-circle d-flex align-items-center justify-content-center p-3 mr-3" style={{ height: '50px', width: '50px' }}>
                      <FontAwesomeIcon icon="fa-regular fa-users" />

                    </Button>
                    <div>
                      <span class="text-sm">Public <br /> Tous le monde sur ou en dehors de Facebook</span>
                    </div>
                    <Form.Check
                      type="radio"
                      label={
                        <></>
                      }
                      name="radio-group"
                      value="public"
                      checked={selectedOption === "public"}
                      onChange={handleOptionChange}
                    />
                  </ListGroup.Item>
                  <ListGroup.Item action variant="light" className="d-flex justify-content-between align-items-center h-100">
                    <Button variant="light" className="rounded-circle d-flex align-items-center justify-content-center p-3 mr-3" style={{ height: '50px', width: '50px' }}>
                      <FontAwesomeIcon icon={['fa', 'user-group']} />
                    </Button>
                    <div>
                      <span class="text-sm">Public <br /> Tous le monde sur ou en dehors de Facebook</span>
                    </div>
                    <Form.Check
                      type="radio"
                      label={
                        <></>
                      }
                      name="radio-group"
                      value="public"
                      checked={selectedOption === "public"}
                      onChange={handleOptionChange}
                    />
                  </ListGroup.Item>
                  <ListGroup.Item action variant="light" className="d-flex justify-content-between align-items-center h-100">
                    <Button variant="light" className="rounded-circle d-flex align-items-center justify-content-center p-3 mr-3" style={{ height: '50px', width: '50px' }}>
                      <FontAwesomeIcon className="fs-5" icon={faUser} />
                    </Button>
                    <div>
                      <span class="text-sm">Public <br /> Tous le monde sur ou en dehors de Facebook</span>
                    </div>
                    <Form.Check
                      type="radio"
                      label={
                        <></>
                      }
                      name="radio-group"
                      value="public"
                      checked={selectedOption === "public"}
                      onChange={handleOptionChange}
                    />
                  </ListGroup.Item>
                  <ListGroup.Item action variant="light" className="d-flex justify-content-between align-items-center h-100">
                    <Button variant="light" className="rounded-circle d-flex align-items-center justify-content-center p-3 mr-3" style={{ height: '50px', width: '50px' }}>
                      <FontAwesomeIcon className="fs-5" icon={faLock} />
                    </Button>
                    <div>
                      <span class="text-sm">Public <br /> Tous le monde sur ou en dehors de Facebook</span>
                    </div>
                    <Form.Check
                      type="radio"
                      label={
                        <></>
                      }
                      name="radio-group"
                      value="public"
                      checked={selectedOption === "public"}
                      onChange={handleOptionChange}
                    />
                  </ListGroup.Item>
                  <ListGroup.Item action variant="light" className="d-flex justify-content-between align-items-center h-100">
                    <Button variant="light" className="rounded-circle d-flex align-items-center justify-content-center p-3 mr-3" style={{ height: '50px', width: '50px' }}>
                      <FontAwesomeIcon className="fs-5" icon={faGear} />
                    </Button>
                    <div>
                      <span class="text-sm">Public <br /> Tous le monde sur ou en dehors de Facebook</span>
                    </div>
                    <Form.Check
                      type="radio"
                      label={
                        <></>
                      }
                      name="radio-group"
                      value="public"
                      checked={selectedOption === "public"}
                      onChange={handleOptionChange}
                    />
                  </ListGroup.Item>
                </ListGroup>
              </Form>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="secondary" onClick={handleClose}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>
      )}
      {modalState === 3 && (
        <Modal show={show} onHide={handleClose} centered>
          <Modal.Header closeButton>
            <Button variant="light" className="rounded-circle d-flex align-items-center justify-content-center p-3 mr-3" style={{ height: '50px', width: '50px' }} onClick={() => setModalState(1)}>
              <FontAwesomeIcon className="fs-5" icon={faArrowLeftLong} />
            </Button>
            <Modal.Title>Ajouter à votre publication</Modal.Title>
          </Modal.Header>
          <Modal.Body className="modal-body">
            <div className=" my-1 d-grid gap-2 d-md-flex">
              <Button color="primary" className="text-muted flex-grow-1 me-md-2 rounded d-flex align-items-center" variant="light"><img src={gallery} alt="Humeur icon" style={{ width: '30px', height: '30px' }} />Photo / Vidéo</Button>
              <Button color="primary" className="flex-grow-1 rounded d-flex align-items-center" variant="light"><FontAwesomeIcon className="text-primary pointer" icon={faUserTag} />Humeur / Activité</Button>
            </div>
            <div className="my-3 d-grid gap-2 d-md-flex">
              <Button color="primary" className="text-muted flex-grow-1 me-md-2 rounded d-flex align-items-center" variant="light"><img src={humeur} alt="Humeur icon" style={{ width: '30px', height: '30px' }} />Photo / Vidéo</Button>
              <Button color="primary" className="flex-grow-1 rounded d-flex align-items-center" variant="light"><FontAwesomeIcon className="text-danger pointer" icon={faLocationDot} />Humeur / Activité</Button>
            </div>
            <div className=" my-3 d-grid gap-2 d-md-flex">
              <Button color="primary" className="text-muted flex-grow-1 me-md-2 rounded d-flex align-items-center" variant="light"><img src={flag} alt="Humeur icon" style={{ width: '30px', height: '30px' }} />Photo / Vidéo</Button>
              <Button color="primary" className="text-muted flex-grow-1 me-md-2 rounded d-flex align-items-center" variant="light"><img src={gif} alt="Humeur icon" style={{ width: '30px', height: '30px' }} />Photo / Vidéo</Button>
            </div>
            <div className="my-1 d-grid  d-md-flex">
              <Button color="primary" className="text-muted flex-grow-5 rounded d-flex align-items-center" variant="light"><img src={video} alt="Humeur icon" style={{ width: '30px', height: '30px' }} />Photo / Vidéo</Button>
            </div>
          </Modal.Body>

          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="secondary" onClick={handleClose}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>
      )}

      {modalState === 4 && (
        <Modal show={show} onHide={handleClose} centered>
          <Modal.Header closeButton>
            <Modal.Title>Create Post</Modal.Title>
          </Modal.Header>
          <Modal.Body className="modal-body">
            <div className="my-1 p-1">
              <div className="d-flex flex-column">
                <div className="d-flex align-items-center">
                  <div className="p-2">
                    <img src="https://source.unsplash.com/collection/happy-people" alt="from fb" className="rounded-circle" style={{ width: '38px', height: '38px', objectFit: 'cover' }} />
                  </div>
                  <div>
                    <p className="m-0 fw-bold">John</p>
                    
                    <Button variant="secondary" onClick={() => setModalState(2)}>
                      Close
                    </Button>
                  </div>
                </div>
                <div>
                  <textarea cols={30} rows={5} className="form-control border-0" defaultValue={""} />
                </div>
                <div className="d-flex justify-content-between align-items-center">
                  <img src="https://www.facebook.com/images/composer/SATP_Aa_square-2x.png" className="pointer" alt="fb text" style={{ width: '30px', height: '30px', objectFit: 'cover' }} />
                  <i className="fa-regular fa-face-smile-relaxed" />
                </div>
                

                <div className="d-flex justify-content-between border border-1 border-light rounded p-3 mt-3">
                  <p onClick={() => setModalState(3)} className="m-0 text-black" style={{ textDecoration: "none" }}>Add to your post</p>
                  <div>
                    <FontAwesomeIcon className="fs-5 text-success pointer mx-1" icon={faImages} onClick={() => setModalState(4)} />
                    <FontAwesomeIcon className="fs-5 text-primary pointer mx-1" icon={faUserTag} onClick={() => setModalState(5)} />
                    <FontAwesomeIcon className="fs-5 text-warning pointer mx-1" icon={faFaceLaugh} />
                    <FontAwesomeIcon className="fs-5 text-danger pointer mx-1" icon={faLocationDot} />
                    <FontAwesomeIcon className="fs-5 text-info pointer mx-1" icon={faFlag} />
                    <FontAwesomeIcon className="fs-5 text-secondary pointer mx-1" icon={faEllipsis} />
                  </div>
                </div>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="secondary" onClick={handleClose}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>
      )}

      {modalState === 5 && (
        <Modal show={show} onHide={handleClose} centered>
          <Modal.Header closeButton>
            <Button variant="light" className="rounded-circle d-flex align-items-center justify-content-center p-3 mr-3" style={{ height: '50px', width: '50px' }} onClick={() => setModalState(1)}>
              <FontAwesomeIcon className="fs-5" icon={faArrowLeftLong} />
            </Button>
            <Modal.Title>Identifier des personnes</Modal.Title>
          </Modal.Header>

          <Modal.Body className="modal-body d-flex flex-wrap">
            <Form className="d-flex">
              <Form.Control type="search" placeholder="Search" className="me-2" aria-label="Search"
              />
              <Button variant="outline-success">Search</Button>
            </Form>

          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="secondary" onClick={handleClose}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>
      )}
    </>
  );
}

export default CreatePost;