import { useState } from 'react';

const SearchBar = ({ setSearchTerm }) => {
    const [searchValue, setSearchValue] = useState("");


    //gère les modifications de la valeur d'un champ de saisie
    //la fonction prend un objet événement 'e'comme argument,
    //répond à un changement de la valeur d'entrée.
    //La fonction utilise ensuite la setSearchValuefonction pour mettre à jour l'état
    //de l'application avec la nouvelle valeur du champ d'entrée, comme spécifié par e.target.value.
    //Cela permet à l'application de garder une trace de la valeur de recherche actuelle et d'y répondre en conséquence.
    const handleSearchInputChanges = (e) => {
        setSearchValue(e.target.value);
    }
    // remet a zero le champ d'entrée de recherche
    const resetInputField = () => {
        setSearchValue("")
    }
    // appelle la fonction de recherche avec la valeur de recherche actuelle et la fonction de réinitialisation du champ d'entrée
    const callSearchFunction = (e) => {
        e.preventDefault();
        setSearchTerm(searchValue);
        resetInputField();
    }
    // affichage de la barre de recherche et de son bouton avec l'appel de la fonction 'callSearchFunction'
    return (
        <form className="search">
            <input
                value={searchValue}
                onChange={handleSearchInputChanges}
                type="text"
            />
            <input onClick={callSearchFunction} type="submit" value="SEARCH" />
        </form>
    );
}

export default SearchBar;





