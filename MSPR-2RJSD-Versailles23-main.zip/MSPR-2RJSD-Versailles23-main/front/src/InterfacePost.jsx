import 'bootstrap/dist/css/bootstrap.css';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import axios from "axios";


import love from './icones/love.png';
import share from './icones/share.png';
import commentaire from './icones/commentaire.png';
import jaime from './icones/jaime.png';


import React, { useState } from 'react';
import './css/CreatePost.css';
import 'bootstrap/dist/css/bootstrap.css';


//les import des posts
import { Dropdown, DropdownButton, Image, Container, Row, Col, Badge, Accordion, Card, Media, Collapse, setImage } from 'react-bootstrap';
import { faThumbsUp, faCircleHeart, faGrinSquint, faCommentAlt } from "@fortawesome/free-solid-svg-icons";

import { useNavigate } from "react-router-dom";
function InterfacePost() {

  //back 
  const [post, setPost] = useState({ content: "", image: "" });

  const handleChange = (event) => {
    setPost({ ...post, [event.target.name]: event.target.value });
  };
  const navigate = useNavigate()
  const handleSubmit = async (event) => {

    event.preventDefault();
    try {
      await axios.post("http://localhost:3001/post/create_post", post)
      navigate("/test")

    } catch (err) {
      console.log(err)
    }
  };




  //front
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  //Afficher les posts
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const toggle = () => setDropdownOpen(prevState => !prevState);
  const [open, setOpen] = useState(false);

  //inserer une image
  const [showDiv, setShowDiv] = useState(false);
  const [image, setImage] = useState(null);

  const handleClick = () => {
    setShowDiv(!showDiv);
  };

  const handleFileUpload = (event) => {
    setImage(event.target.files[0]);
  };

  const handleDrop = (event) => {
    event.preventDefault();
    setImage(event.dataTransfer.files[0]);
  };



  return (
    <>

      <div className="container-fluid">
        <div className="row justify-content-evenly">
          <div className="col-11 col-lg-12 pb-5">
            <div className="d-flex flex-column justify-content-center w-100 mx-auto" style={{ paddingTop: '56px', maxWidth: '680px' }}>
              
          
              {/*  posts */}
              <div class="bg-white p-4 rounded shadow mt-3">
                <div className="d-flex justify-content-between">
                  <div className="d-flex align-items-center">
                    <Image src="https://profileme.app/wp-content/uploads/2021/01/cropped-ProfileMe-06.jpg" alt="avatar" roundedCircle className="me-2" style={{ width: '38px', height: '38px' }} />
                    <div>
                      <p className="m-0 fw-bold">John</p>
                      <span className="text-muted fs-7">17 Juillet à 13:23</span>
                    </div>
                  </div>
                  <DropdownButton id="dropdown-basic-button" title={<i className="fas fa-ellipsis-h"></i>} variant="link">
                    <Dropdown.Item href="#/action-1">Editer le poste</Dropdown.Item>
                    <Dropdown.Item href="#/action-2">Supprimer le oste</Dropdown.Item>
                  </DropdownButton>
                </div>
                <div class="mt-3">
                  <div>
                    <Row>
                      <Col>
                        <p>
                          Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                          Quae fuga incidunt consequatur tenetur doloremque officia
                          corrupti provident tempore vitae labore?
                        </p>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <Image src="https://st.depositphotos.com/1817276/1444/i/600/depositphotos_14442485-stock-photo-cloudy-blue-sky-and-wood.jpg" alt="post image" fluid rounded />
                      </Col>
                    </Row>
                  </div>
                  <div className="post__comment mt-3 position-relative">
                    
                    <div className="options d-flex flex-column flex-lg-row mt-3">
                      <div className="list dropdown-item rounded d-flex " type="button">
                        <FontAwesomeIcon icon={faThumbsUp} className="text-primary" />
                        <img src={love} alt="Image" type="button" />
                      </div>

                      <div className="list dropdown-item rounded d-flex align-items-center justify-content-center" type="button">
                        <p className="m-0 text-muted fs-7">Mardi </p>
                        <p className="m-0 text-muted fs-7"> 2 commentaires</p>
                      </div>
                    </div>
                    
                  </div>
                  <hr />
                  <div className="options d-flex flex-column flex-lg-row mt-3">
                    <div className="list dropdown-item rounded d-flex align-items-center justify-content-center" type="button">
                      <img src={share} alt="Humeur icon" />
                      <p className="m-0 text-muted">J'aime</p>
                    </div>

                    <div className="list dropdown-item rounded d-flex align-items-center justify-content-center" type="button">
                      <img src={commentaire} alt="Humeur icon" />
                      <p className="m-0 text-muted">Commenter</p>
                    </div>

                    <div className="list dropdown-item rounded d-flex align-items-center justify-content-center" type="button">
                      <img src={jaime} alt="Humeur icon" />
                      <p className="m-0 text-muted">Partager</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-12 col-lg-3">
          </div>
        </div>
      </div>
      

    </>
  );
}

export default InterfacePost;