import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCalendar, faCamera, faCaretDown, faPen, faPenToSquare, faVideoCamera } from '@fortawesome/free-solid-svg-icons';
import { Badge } from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css';
import './css/Profile.css';
import CreatePost from "./CreatePost";
import InterfacePost from "./InterfacePost";
import NavBar from "./NavBar";
import ModaleMenu from "./views/ModaleMenu";
import Logout from "./views/logout/logout";

function Profile(props) {
  const user = props.user;
  const post = props.post;
  //const comment = props.comment;

  return (
    <div>
    <NavBar /> <Logout />
      <div className="profile-page">
        <div id="profile-upper">
          <div>
            <div id="profile-banner-image">
              <img src={user.couverturepics} alt="image de couverture"></img>
            </div>
          </div>
          <div id="profile-d">
            <div id="profile-pic">
              <img src={user.profilepics}></img>
            </div>
            <div id="u-name">{user.name}</div>
            <div class="tb" id="m-btns">
              <div class="m-btn"><FontAwesomeIcon icon={faCamera} /><span>  Ajouter une photo de couverture</span></div>
            </div>
          </div>

        </div>
        <div id="main-content">
          <div class="tb">
            <div class="td" id="l-col">
              <div class="l-cnt">
                <div class="cnt-label">
                  <i class="l-i" id="l-i-i"></i>
                  <span> Intro</span>
                  <div class="lb-action"><FontAwesomeIcon icon={faPen} /></div>
                </div>
                <div id="i-box">
                  <div id="intro-line">Front-end Engineer</div>
                  <div id="u-occ">I love making applications with Angular!!!!!!</div>
                  <div id="u-loc"><a href="https://www.google.com/maps/search/versailles/@48.8038666,2.0841753,13z/data=!3m1!4b1">Versailles</a>, <a href="https://www.google.com/maps/place/France/@46.1313542,-2.4365078,6z/data=!3m1!4b1!4m5!3m4!1s0xd54a02933785731:0x6bfd3f96c747d9f7!8m2!3d46.227638!4d2.213749">France</a>
                  </div>
                </div>
              </div>
              <div class="l-cnt l-mrg">
                <div class="cnt-label">
                  <i class="l-i" id="l-i-p"></i>
                  <span> Photos</span>
                  <div class="lb-action" id="b-i"><FontAwesomeIcon icon={faPen} /></div>
                </div>
                <div id="photos">
                  <div class="tb">
                    <div class="tr">
                      <div class="td"></div>
                      <div class="td"></div>
                      <div class="td"></div>
                    </div>
                    <div class="tr">
                      <div class="td"></div>
                      <div class="td"></div>
                      <div class="td"></div>
                    </div>
                    <div class="tr">
                      <div class="td"></div>
                      <div class="td"></div>
                      <div class="td"></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="l-cnt l-mrg">
                <div class="cnt-label">
                  <i class="l-i" id="l-i-k"></i>
                  <span> Did You Know<i id="k-nm">1</i></span>
                </div>
                <div>
                  <div class="q-ad-c">
                    <a href="#" class="q-ad">
                      <img src={user.profilepics}></img>
                      <span>My favorite superhero is...</span>
                    </a>
                  </div>
                  <div class="q-ad-c">
                    <a href="#" class="q-ad" id="add_q">
                      <FontAwesomeIcon icon={faPen} />
                      <span>Add Answer</span>
                    </a>
                  </div>
                </div>
              </div>
              <div id="t-box">
                <a href="terms">Privacy</a> <a href="terms">Terms</a> <a href="#">Advertising</a> <a href="#">Ad Choices</a> <a
                  href="#">Cookies</a> <span id="t-more">More <FontAwesomeIcon icon={faCaretDown} /></span>
                <div id="cpy-nt">Facebook &copy; <span id="curr-year"></span></div>
              </div>
            </div>
            <div class="td" id="m-col">


              <div class="m-mrg" id="p-tabs">
                <div class="tb">
                  <div class="td">
                    <div class="tb" id="p-tabs-m">
                      <div class="td active nod"><span>PUBLICATIONS</span></div>
                      <div class="td nod"><span>A PROPOS</span></div>
                      <div class="td nod"><span>AMIS</span></div>
                      <div class="td nod"><span>PHOTOS</span></div>
                      <div class="td nod"><span>VIDEOS</span></div>
                      <div class="td nod"><span>LIEUX</span></div>
                      <div class="td nod"><span>PLUS</span></div> <FontAwesomeIcon icon={faCaretDown} />
                    <ModaleMenu />
                    </div>
                    <div class="tb" id="p-tabs-m">
                      <Badge bg="light text-dark mt-3 w-25 border" as="Button">
                        ...
                      </Badge>
                    </div>
                  </div>
                </div>

              </div>
              <CreatePost />
              <InterfacePost />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Profile;