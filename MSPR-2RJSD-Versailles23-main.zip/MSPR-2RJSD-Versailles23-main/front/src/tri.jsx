import React from 'react';
import './css/index.css';

const useSortableData = (items, config = null) => {
  const [sortConfig, setSortConfig] = React.useState(config);

  const sortedItems = React.useMemo(() => {
    let sortableItems = [...items];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [items, sortConfig]);

  const requestSort = (key) => {
    let direction = 'ascending';
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === 'ascending'
    ) {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  return { items: sortedItems, requestSort, sortConfig };
};

const ProductTable = (props) => {
  const { items, requestSort, sortConfig } = useSortableData(props.products);
  const getClassNamesFor = (name) => {
    if (!sortConfig) {
      return;
    }
    return sortConfig.key === name ? sortConfig.direction : undefined;
  };
  return (
    <table>
      <caption>Amis</caption>
      <thead>
        <tr>
          <th>
            <button
              type="button"
              onClick={() => requestSort('name')}
              className={getClassNamesFor('name')}
            >
              Nom
            </button>
          </th>
          <th>
            <button
              type="button"
              onClick={() => requestSort('birth')}
              className={getClassNamesFor('birth')}
            >
              Anniversaire
            </button>
          </th>
          <th>
            <button
              type="button"
              onClick={() => requestSort('invitation')}
              className={getClassNamesFor('invitation')}
            >
              Invitations
            </button>
          </th>
        </tr>
      </thead>
      <tbody>
        {items.map((item) => (
          <tr key={item.id}>
            <td>{item.name}</td>
            <td>{item.birth}</td>
            <td>{item.invitation}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default function Tri() {
  return (
    <div className="Tri">
      <ProductTable
        products={[
          { id: 1, name: 'Thomas H', birth: 12, invitation: 1 },
          { id: 2, name: 'Ethan', birth: 18, invitation: 0 },
          { id: 3, name: 'Thomas C', birth: 14, invitation: 0 },
          { id: 4, name: 'Thomas G', birth: 2, invitation: 1 },
          { id: 5, name: 'benji', birth: 12, invitation: 0 },
          { id: 6, name: 'Kilian', birth: 27, invitation: 0 },
          { id: 7, name: 'Valentin', birth: 12, invitation: 1 },
        ]}
      />
    </div>
  );
}
