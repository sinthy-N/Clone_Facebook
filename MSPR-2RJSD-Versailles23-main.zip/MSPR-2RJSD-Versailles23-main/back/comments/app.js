const express = require('express');
const app = express();
const port = 3001;

// routes
const example = require('../routes/example')

app.use("/example", example);

app.listen(port, () => {
    console.log(`Visages back listening on port ${port}`)
})
