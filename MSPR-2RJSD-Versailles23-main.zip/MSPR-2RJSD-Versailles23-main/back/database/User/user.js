import connection from "../config.js"

//Ici se trouve les requêtes liés à une entité.
//Vous trouverez ici toutes les requêtes liés aux utilisateurs.

export async function createUser(firstname,lastname,email,password,birth_date,gender) {
    var now_date= new Date();
    var date_month = now_date.getUTCDay()
    var date_day = now_date.getUTCDate()
    var date_year = now_date.getUTCFullYear()
    var full_date = date_year+"-"+date_month+"-"+date_day+" 00:00:00"
    const [result] = await connection.query(`
    INSERT INTO users (firstname,lastname,email,password,birth_date,gender,created_at)
    VALUES (?,?,?,?,?,?,?)
    `,[firstname,lastname,email,password,birth_date,gender,full_date])
    const id = result.InsertId
    return getUser(id)
    
}
export function updateUser() {

}

export function deleteUser() {

} 

export async function getUsers() {
    const [result] = await connection.query("SELECT* FROM users")
    return result
}

export async function getUser(id) {
    const [result] = await connection.query(`
    SELECT *
    FROM users
    WHERE id = ?
    `, [id])
    return result[0]
}
export async function getUserByUsername(username) {
    const [result] = await connection.query(`
    SELECT *
    FROM user
    WHERE name = ?
    `, [username])
    return result[0]
}

