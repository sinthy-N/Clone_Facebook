import connection from "../config.js"

//Ici se trouve les requêtes liés à une entité.
//Vous trouverez ici toutes les requêtes liés aux utilisateurs.

export async function createPost(firstname,lastname,email,password,birth_date,gender) {
    var now_date= new Date();
    var date_month = now_date.getUTCDay()
    var date_day = now_date.getUTCDate()
    var date_year = now_date.getUTCFullYear()
    var full_date = date_year+"-"+date_month+"-"+date_day+" 00:00:00"
    const [result] = await connection.query(`
    INSERT INTO posts (username,content,image,created_at)
    VALUES (?,?,?,?,?,?,?)
    `,[username,content,image,created_at])
    const id = result.InsertId
    return getPost(id)
    
}
export function updatePost() {

}

export function deletePost() {

} 

export async function getPosts() {
    const [result] = await connection.query("SELECT* FROM posts")
    return result
}

export async function getPost(id) {
    const [result] = await connection.query(`
    SELECT *
    FROM posts
    WHERE id = ?
    `, [id])
    return result[0]
}
export async function getPostByUsername(username) {
    const [result] = await connection.query(`
    SELECT *
    FROM post
    WHERE name = ?
    `, [username])
    return result[0]
}

