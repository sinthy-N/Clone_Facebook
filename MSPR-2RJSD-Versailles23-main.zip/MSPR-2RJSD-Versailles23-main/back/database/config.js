import mysql from 'mysql2';

const connection = mysql.createPool({
    host: 'localhost',
    port: 8889,
    user: 'root',
    password: 'root',
    database: 'visages'
}).promise();

export default connection;