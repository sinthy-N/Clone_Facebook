const express = require('express');
const router = express.Router();

// define the /example home page route
router.get('/', function(req, res) {
    res.send({
        message: "Hello Versailles :)"
    });
});

module.exports = router;