import express from 'express';
import { getPosts,getPost, createPost } from '../database/Post/post.js';
const router = express.Router();


//Ici se trouves les appels à vos différentes requêtes de votre entités
//selon la route employé

router.get('/', async (req, res) => { // à la routes localhost:3001/post la fonctions getPosts() est appelé.
    const posts = await getPosts()
    res.send(posts)
});
router.get('/:id', async (req, res) => { // à la routes localhost:3001/post/:id la fonctions getPost(id) est appelé.
    const id = req.params.id
    const post = await getPost(id)
    res.send(post)
});
router.post('/createpost', async (req,res)=>{ // à la routes localhost:3001/post/create la fonctions createPosts() est appelé.
    const {username,content,image} = req.body
    const note = await createPost(username,content,image)
    res.status(201).send(note)
})



export default router;