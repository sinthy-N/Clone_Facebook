import express from 'express';
import { getUsers,getUser, createUser } from '../database/User/user.js';
const router = express.Router();


//Ici se trouves les appels à vos différentes requêtes de votre entités
//selon la route employé

router.get('/', async (req, res) => { // à la routes localhost:3001/user la fonctions getUsers() est appelé.
    const users = await getUsers()
    res.send(users)
});
router.get('/:id', async (req, res) => { // à la routes localhost:3001/user/:id la fonctions getUser(id) est appelé.
    const id = req.params.id
    const user = await getUser(id)
    res.send(user)
});
router.post('/create_user', async (req,res)=>{ // à la routes localhost:3001/user/create la fonctions createUsers() est appelé.
    const {firstname,lastname,email,password,birth_date,gender} = req.body
    const note = await createUser(firstname,lastname,email,password,birth_date,gender)
    res.status(201).send(note)
})



export default router;