import express from 'express';
import cors from 'cors';
const app = express();
const port = 3001;
app.use(express.json())
app.use(express.urlencoded({extended: false}));
app.use(cors())

// Routes vers les différents routes principales faisant références a vos entités.

import user from './routes/user.js'; //Route principale de l'entité User qui renvoie vers les sous routes :
app.use("/user", user)              // user/id , user/create etc

app.listen(port, () => {
    console.log(`Visages back listening on port ${port}`)
})
